#ifndef GLTIMER_H
#define GLTIMER_H

#include<common.h>

class GLTimer
{
    public:
        GLTimer();
        virtual ~GLTimer();

        clock_t startTime;

    protected:

    private:
};

#endif // GLTIMER_H
