#include "GLTimer.h"

GLTimer::GLTimer()
{
    //ctor
}

GLTimer::~GLTimer()
{
    //dtor
}
